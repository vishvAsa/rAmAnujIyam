+++
title = "+देवनाथ-भाव-प्रकाशः"
+++

TODO: परिष्कार्यं

श्रीभाष्यभावप्रकाशः  
U ஸ்ரீமாலோலன் का. इ. देवनाथः  
नृसिंहप्रिया ट्रस्ट् चेन्नई  
२००६  
श्रीभाष्यभावप्रकाशः  
का. इ. देवनाथः दर्शनसङ्कायप्रमुखः  
राष्ट्रियसंस्कृतविद्यापीठम्, तिरुपतिः  
नृसिंहप्रिया ट्रस्ट्, चेन्नई  
[[2008]]
श्रीभाष्यभावप्रकाशः   
Śrībhāṣyaprakāśaḥ  
Author  
Prof. K.E.Devanathan   
Dean, Facutly of Darsanas   
Rashtriya Sanskrit Vidyapeetha Tirupati  
Published by-  
Sri Nrisimha Priya Trust, Chennai  
Year 2006  
Copies can be had from :   
Nrisimha Priya Trust  
30, Venkatesha Agraharam, Mylapore, 
Chennai - 600 004 

ஸ்ரீலஷ்மீந்ருஸிம்ஹ திவ்யபாதுகாஸேவக  
ஸ்ரீவண்டகோப ஸ்ரீநாரரியிணயதீந்த்ர மஹாதேசிகன் தாபிஷேகம் அவ்யய கார்த்திகை - திருஉத்திரட்டாதி -30-11-2006 
